"""Hand-crafted tapered evaluation for Bini (the fallback when the NNUE is not in use).

Every table below is generated at import from a few named terms, so the numbers are ours and
the intent is readable: centralisation, pawn advancement, king shelter in the middlegame and
king activity in the endgame. Scores are centipawns from the side to move's point of view.
"""

from __future__ import annotations

import numpy as np
from numba import njit

from bini_calib import CALIB
from bini_board import (
    BLACK,
    KING_ATT,
    KNIGHT_ATT,
    PAWN_ATT,
    S_SIDE,
    SQBB,
    WHITE,
    ZERO,
    bishop_att,
    lsb,
    popcount,
    rook_att,
)

U64 = np.uint64

# material, middlegame / endgame (index by piece type 1..6)
EG_DRAW = int(__import__('os').environ.get('BINI_EG_DRAW', '1'))  # 1: dead pawnless material draws score 0
MAT_MG = np.array([0, 82, 337, 365, 477, 1025, 0], dtype=np.int64)
MAT_EG = np.array([0, 94, 281, 297, 512, 936, 0], dtype=np.int64)
# plain values for SEE and move ordering
SEE_VALUE = np.array([0, 100, 320, 330, 500, 950, 20000], dtype=np.int64)
PHASE_INC = np.array([0, 0, 1, 1, 2, 4, 0], dtype=np.int64)
PHASE_MAX = 24

TEMPO = 12


def _centre_dist(sq: int) -> float:
    r, f = divmod(sq, 8)
    return max(abs(f - 3.5), abs(r - 3.5)) - 0.5  # 0 for the four centre squares, 3 for corners


def _build_tables() -> tuple[np.ndarray, np.ndarray]:
    """PST_MG / PST_EG indexed by (piece_code - 1) * 64 + square, black mirrored."""
    mg = np.zeros(12 * 64, dtype=np.int64)
    eg = np.zeros(12 * 64, dtype=np.int64)
    pawn_adv_mg = [0, 0, 4, 9, 18, 32, 55, 0]
    pawn_adv_eg = [0, 0, 8, 16, 30, 55, 95, 0]
    for sq in range(64):
        r, f = divmod(sq, 8)
        cd = _centre_dist(sq)
        # pawn: advance, prefer central pawns advanced, discourage f/g/h pawns wandering early
        p_mg = pawn_adv_mg[r] + (12 if (f in (3, 4) and 3 <= r <= 4) else 0) - (6 if (f in (0, 7) and r == 1) else 0)
        if r == 1 and f in (3, 4):
            p_mg -= 12  # unmoved d/e pawns block development
        p_eg = pawn_adv_eg[r] + (4 if f in (3, 4) else 0)
        # knight: strong centralisation, rim penalty
        n_mg = int(28 - 14 * cd)
        n_eg = int(18 - 9 * cd)
        if r == 0:
            n_mg -= 10
        # bishop: mild centralisation, long diagonals, back rank slightly negative
        b_mg = int(16 - 6 * cd) + (6 if (r == f or r + f == 7) and cd <= 1 else 0)
        b_eg = int(14 - 5 * cd)
        if r == 0:
            b_mg -= 8
        # rook: seventh rank, central files
        r_mg = (18 if r == 6 else 0) + (5 if f in (3, 4) else 0) - (4 if f in (0, 7) and r == 0 else 0)
        r_eg = 8 if r == 6 else 0
        # queen: slight centralisation, not out early
        q_mg = int(6 - 3 * cd) - (8 if r >= 4 else 0)
        q_eg = int(10 - 4 * cd)
        # king: shelter in the middlegame, centre in the endgame
        k_mg = (24 if (r == 0 and f in (1, 2, 6, 7)) else 0) + (-10 if (r == 0 and f in (3, 4)) else 0)
        k_mg -= 35 * r  # any advance of the king in the middlegame is punished
        k_mg -= int(8 * (3 - cd)) if r > 0 else 0
        k_eg = int(36 - 14 * cd)
        for code, vmg, veg in ((1, p_mg, p_eg), (2, n_mg, n_eg), (3, b_mg, b_eg), (4, r_mg, r_eg), (5, q_mg, q_eg), (6, k_mg, k_eg)):
            mg[(code - 1) * 64 + sq] = vmg
            eg[(code - 1) * 64 + sq] = veg
            msq = (7 - r) * 8 + f
            mg[(code + 6 - 1) * 64 + msq] = vmg
            eg[(code + 6 - 1) * 64 + msq] = veg
    return mg, eg


PST_MG, PST_EG = _build_tables()

PASSED_MG = np.array([0, 4, 8, 16, 30, 55, 95, 0], dtype=np.int64)
PASSED_EG = np.array([0, 10, 18, 35, 65, 115, 185, 0], dtype=np.int64)
ISOLATED_MG, ISOLATED_EG = 11, 14
DOUBLED_MG, DOUBLED_EG = 9, 20
BISHOP_PAIR_MG, BISHOP_PAIR_EG = 28, 48
ROOK_OPEN_MG, ROOK_OPEN_EG = 26, 10
ROOK_SEMI_MG, ROOK_SEMI_EG = 12, 6
MOB_MG = np.array([0, 0, 4, 4, 2, 1, 0], dtype=np.int64)
MOB_EG = np.array([0, 0, 3, 4, 4, 3, 0], dtype=np.int64)
SHIELD_MG = 12
KING_OPEN_FILE_MG = 18
ATTACK_WEIGHT = np.array([0, 0, 2, 2, 3, 5, 0], dtype=np.int64)
# king danger by attack units: gentle then steep
KING_DANGER = np.array([0, 0, 2, 5, 9, 15, 22, 31, 42, 55, 70, 87, 106, 127, 150, 175, 200, 225, 250, 275, 300, 320, 340, 360, 380, 400, 420, 440, 460, 480, 500, 520], dtype=np.int64)

FILE_MASK = np.array([0x0101010101010101 << f for f in range(8)], dtype=np.uint64)
ADJ_FILES = np.zeros(8, dtype=np.uint64)
for _f in range(8):
    _m = 0
    if _f > 0:
        _m |= 0x0101010101010101 << (_f - 1)
    if _f < 7:
        _m |= 0x0101010101010101 << (_f + 1)
    ADJ_FILES[_f] = _m
# squares in front of a pawn (same and adjacent files) for passed-pawn tests
FRONT_SPAN = np.zeros((2, 64), dtype=np.uint64)
for _sq in range(64):
    _r, _f = divmod(_sq, 8)
    _files = int(FILE_MASK[_f] | ADJ_FILES[_f])
    _w = 0
    for _rr in range(_r + 1, 8):
        _w |= 0xFF << (_rr * 8)
    _b = 0
    for _rr in range(0, _r):
        _b |= 0xFF << (_rr * 8)
    FRONT_SPAN[0, _sq] = _files & _w
    FRONT_SPAN[1, _sq] = _files & _b
CENTRE_MANHATTAN = np.array([max(abs((s & 7) - 3.5), 0) + max(abs((s >> 3) - 3.5), 0) for s in range(64)]).astype(np.int64)


@njit(cache=False, boundscheck=False)
def _dist(a, b):
    df = (a & 7) - (b & 7)
    dr = (a >> 3) - (b >> 3)
    if df < 0:
        df = -df
    if dr < 0:
        dr = -dr
    return df if df > dr else dr


@njit(cache=False, boundscheck=False)
def evaluate_hce(bb, st, pcs):
    """Classical evaluation removed from the shipped build (finals, 30 s init): it is never reached with the
    NNUE on and cost several seconds of compile. Kept as a stub so the call site in evaluate() types.  Returns 0."""
    return 0


@njit(cache=False, boundscheck=False)
def game_phase(bb):
    phase = 0
    for i in range(1, 5):
        phase += PHASE_INC[i + 1] * (popcount(bb[i]) + popcount(bb[i + 6]))
    if phase > PHASE_MAX:
        phase = PHASE_MAX
    return phase


@njit(cache=False, boundscheck=False)
def calibrate(bb, side, score):
    """Subtract the measured systematic bias of the net for this piece count and material
    imbalance (bini_calib.CALIB, side-to-move view)."""
    n = popcount(bb[14])
    m = popcount(bb[0]) - popcount(bb[6]) + 3 * (popcount(bb[1]) + popcount(bb[2]) - popcount(bb[7]) - popcount(bb[8])) + 5 * (popcount(bb[3]) - popcount(bb[9])) + 9 * (popcount(bb[4]) - popcount(bb[10]))
    if side == BLACK:
        m = -m
    if m > 5:
        m = 5
    elif m < -5:
        m = -5
    return score - CALIB[n * 11 + m + 5]


@njit(cache=False, boundscheck=False)
def endgame_scale(bb, score):
    """Draw knowledge in front of the network (pawnless positions only; everything else is untouched).
    Dead draws score 0: identical piece sets (KRvKR, KQvKQ, KBvKB, KNvKN, KRRvKRR ...), at most one minor
    piece each (KBvKN, KBvK, KNvK), or two knights against a bare king. Otherwise, with no pawns a side
    needs at least a rook's worth of extra material to win (KRvKB, KRBvKR and the like), so such scores
    are divided by 8. Score is from the side to move's view; every rule is symmetric."""
    if bb[0] != ZERO or bb[6] != ZERO:
        return score
    n_w = popcount(bb[1]); b_w = popcount(bb[2]); r_w = popcount(bb[3]); q_w = popcount(bb[4])
    n_b = popcount(bb[7]); b_b = popcount(bb[8]); r_b = popcount(bb[9]); q_b = popcount(bb[10])
    npm_w = MAT_MG[2] * n_w + MAT_MG[3] * b_w + MAT_MG[4] * r_w + MAT_MG[5] * q_w
    npm_b = MAT_MG[2] * n_b + MAT_MG[3] * b_b + MAT_MG[4] * r_b + MAT_MG[5] * q_b
    if EG_DRAW != 0:
        if n_w == n_b and b_w == b_b and r_w == r_b and q_w == q_b:
            return 0
        if npm_w <= MAT_MG[3] and npm_b <= MAT_MG[3]:
            return 0
        if (n_w == 2 and npm_w == 2 * MAT_MG[2] and npm_b == 0) or (n_b == 2 and npm_b == 2 * MAT_MG[2] and npm_w == 0):
            return 0
    diff = npm_w - npm_b
    if diff < 0:
        diff = -diff
    if diff < MAT_MG[4]:
        return score // 8
    return score
